module.exports = {

"[project]/.next-internal/server/app/api/chat/visible/route/actions.js [app-rsc] (server actions loader, ecmascript)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
}}),
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/stream [external] (stream, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("stream", () => require("stream"));

module.exports = mod;
}}),
"[externals]/http [external] (http, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("http", () => require("http"));

module.exports = mod;
}}),
"[externals]/url [external] (url, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("url", () => require("url"));

module.exports = mod;
}}),
"[externals]/punycode [external] (punycode, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("punycode", () => require("punycode"));

module.exports = mod;
}}),
"[externals]/https [external] (https, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("https", () => require("https"));

module.exports = mod;
}}),
"[externals]/zlib [external] (zlib, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("zlib", () => require("zlib"));

module.exports = mod;
}}),
"[project]/lib/supabase-server.ts [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "supabaseServer": ()=>supabaseServer
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$module$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@supabase/supabase-js/dist/module/index.js [app-route] (ecmascript) <locals>");
;
const supabaseServer = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$module$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createClient"])(("TURBOPACK compile-time value", "https://gjckhhlxwjxvwrmyitbv.supabase.co"), process.env.SUPABASE_SERVICE_ROLE, {
        auth: {
            persistSession: false
        }
    });
}),
"[project]/app/api/chat/visible/route.ts [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "POST": ()=>POST
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2d$server$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/supabase-server.ts [app-route] (ecmascript)");
;
;
/** ===== PROMPT (tu versión reducida actual) ===== */ const SYSTEM_PROMPT = `
Eres Lexi, asistente legal virtual de Legalia en Colombia.

Aviso al usuario:
"Esta es una orientación general y no sustituye la asesoría profesional de un abogado."

Objetivo:
- Orientar de forma clara y útil en cualquier área del derecho colombiano (normas y jurisprudencia vigentes en lenguaje sencillo).
- Incentivar de forma natural agendar cita con un abogado.
- Captar progresivamente datos clave: nombre, ciudad, teléfono, email, resumen del caso, área legal, urgencia, horario, autorización para WhatsApp.
- Atender máximo 2 casos por conversación. Si hay un tercero, sugerir cita con abogado.
- Filtrar temas no legales y responder con cortesía.

Reglas:
1. Usa lenguaje natural y humano, no tipo formulario.
2. Entrega valor sin convertirte en biblioteca jurídica ni dar clases.
3. En el 3º caso, agradecer y proponer cita.
4. Menciona leyes/jurisprudencia solo si aportan claridad breve.

Mantén coherencia con el hilo. Si el usuario hace referencia a algo ya dicho, continúa sin pedir que lo repita salvo que falte información clave.
`;
function seemsNewCase(input) {
    const t = input.toLowerCase();
    const triggers = [
        'otro tema',
        'además',
        'aparte',
        'también tengo',
        'nuevo caso',
        'otro caso',
        'por otra parte',
        'cambiando de tema'
    ];
    return triggers.some((k)=>t.includes(k));
}
async function getConvMeta(supabase, id) {
    const { data, error } = await supabase.from('conversations').select('case_count, case_notes, lead_id, summary, summary_turns').eq('id', id).single();
    if (error) throw new Error(error.message);
    return data;
}
async function bumpCaseCount(supabase, id) {
    const { data: curr } = await supabase.from('conversations').select('case_count').eq('id', id).single();
    const nextCount = (curr?.case_count ?? 0) + 1;
    await supabase.from('conversations').update({
        case_count: nextCount
    }).eq('id', id);
}
/** Trunca cada mensaje para controlar tokens */ function clip(s, max = 1000) {
    const v = s ?? '';
    return v.length > max ? v.slice(0, max) + '…' : v;
}
/** Decide si toca refrescar resumen (cada N mensajes nuevos) */ function shouldRefreshSummary(totalMsgs, summaryTurns, step = 8) {
    const done = summaryTurns ?? 0;
    return totalMsgs - done >= step;
}
/** Genera/actualiza resumen en background (no bloquea respuesta) */ async function refreshSummaryBG(params) {
    const { supabase, origin, conversationId } = params;
    try {
        // Traigo todos los mensajes para resumir barato:
        const { data: allMsgs } = await supabase.from('messages').select('role, content, created_at').eq('conversation_id', conversationId).order('created_at', {
            ascending: true
        });
        const plain = (allMsgs ?? []).map((m)=>`${m.role}: ${clip(m.content, 400)}`).join('\n');
        const apiKey = process.env.OPENAI_API_KEY;
        if (!apiKey) return;
        const resp = await fetch('https://api.openai.com/v1/chat/completions', {
            method: 'POST',
            headers: {
                Authorization: `Bearer ${apiKey}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                model: 'gpt-4o-mini',
                temperature: 0.2,
                max_tokens: 220,
                messages: [
                    {
                        role: 'system',
                        content: 'Resume en 120-180 palabras el contexto del caso en español. Sé concreto y útil. No inventes.'
                    },
                    {
                        role: 'user',
                        content: plain.slice(0, 8000)
                    } // límite defensivo
                ]
            })
        });
        if (!resp.ok) return;
        const json = await resp.json();
        const summary = json?.choices?.[0]?.message?.content?.trim() ?? null;
        if (summary) {
            await supabase.from('conversations').update({
                summary,
                summary_turns: allMsgs?.length ?? 0
            }).eq('id', conversationId);
        }
    } catch  {
    // silencioso
    }
}
async function POST(req) {
    try {
        const { conversationId, userText } = await req.json();
        if (!conversationId || !userText) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: 'Missing conversationId or userText'
            }, {
                status: 400
            });
        }
        const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2d$server$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["supabaseServer"])();
        // 1) Guardar mensaje user
        const { error: insUserErr } = await supabase.from('messages').insert({
            conversation_id: conversationId,
            role: 'user',
            content: userText
        });
        if (insUserErr) return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: insUserErr.message
        }, {
            status: 400
        });
        // 2) Meta conversación
        const meta = await getConvMeta(supabase, conversationId);
        const isNew = seemsNewCase(userText);
        // Límite 2 casos
        if (isNew && (meta.case_count ?? 0) >= 2) {
            const limitMsg = 'Veo que estás iniciando otro tema. Para revisarlo a fondo y no mezclar casos, puedo agendarte con un abogado de Legalia. ¿Te reservo una cita?';
            await supabase.from('messages').insert({
                conversation_id: conversationId,
                role: 'assistant',
                content: limitMsg
            });
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                ok: true,
                assistant: limitMsg
            });
        }
        if (isNew && (meta.case_count ?? 0) < 2) {
            await bumpCaseCount(supabase, conversationId);
        }
        // 3) Disparar enriquecimiento (no bloqueante)
        ;
        (async ()=>{
            try {
                const origin = new URL(req.url).origin;
                await fetch(`${origin}/api/internal/enrich`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        leadId: meta.lead_id,
                        message: userText
                    })
                });
            } catch  {}
        })();
        // 4) Historial reciente + resumen
        const { data: recent, error: histErr } = await supabase.from('messages').select('role, content, created_at').eq('conversation_id', conversationId).order('created_at', {
            ascending: true
        }).limit(12) // últimos 12 → balance costo/contexto
        ;
        if (histErr) return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: histErr.message
        }, {
            status: 400
        });
        const recentMsgs = (recent ?? []).map((m)=>({
                role: m.role,
                content: clip(m.content, 1100)
            }));
        const contextMessages = [
            {
                role: 'system',
                content: SYSTEM_PROMPT
            },
            ...meta.summary ? [
                {
                    role: 'system',
                    content: `Resumen del caso hasta ahora: ${clip(meta.summary, 1600)}`
                }
            ] : [],
            ...recentMsgs
        ];
        (async ()=>{
            try {
                const { count } = await supabase.from('messages').select('*', {
                    head: true,
                    count: 'exact'
                }).eq('conversation_id', conversationId);
                if (shouldRefreshSummary(count ?? 0, meta.summary_turns, 8)) {
                    await refreshSummaryBG({
                        supabase,
                        origin: new URL(req.url).origin,
                        conversationId
                    });
                }
            } catch  {}
        })();
        // 6) OpenAI (ajustado a economía)
        const apiKey = process.env.OPENAI_API_KEY;
        if (!apiKey) return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: 'OPENAI_API_KEY missing'
        }, {
            status: 500
        });
        const resp = await fetch('https://api.openai.com/v1/chat/completions', {
            method: 'POST',
            headers: {
                Authorization: `Bearer ${apiKey}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                model: 'gpt-4o-mini',
                temperature: 0.3,
                max_tokens: 360,
                messages: contextMessages
            })
        });
        if (!resp.ok) {
            const text = await resp.text();
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: `OpenAI error: ${text}`
            }, {
                status: 500
            });
        }
        const json = await resp.json();
        const assistant = json.choices?.[0]?.message?.content?.trim() || 'No pude generar respuesta.';
        // 7) Guardar respuesta
        const { error: insAErr } = await supabase.from('messages').insert({
            conversation_id: conversationId,
            role: 'assistant',
            content: assistant
        });
        if (insAErr) return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: insAErr.message
        }, {
            status: 400
        });
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            ok: true,
            assistant
        });
    } catch (e) {
        const msg = e instanceof Error ? e.message : 'Unexpected error';
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: msg
        }, {
            status: 500
        });
    }
}
}),

};

//# sourceMappingURL=%5Broot-of-the-server%5D__0e376b4b._.js.map