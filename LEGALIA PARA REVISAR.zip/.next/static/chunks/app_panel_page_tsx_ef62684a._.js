(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_@supabase_node-fetch_browser_b1ac0bb2.js",
  "static/chunks/node_modules_5c8efaf6._.js",
  "static/chunks/_a5230b57._.js"
],
    source: "dynamic"
});
