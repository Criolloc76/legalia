export default function Home() {
  return (
    <main className="min-h-screen grid place-items-center bg-gray-50">
      <h1 className="text-4xl font-bold text-blue-600">Legalia OK</h1>
    </main>
  );
}
